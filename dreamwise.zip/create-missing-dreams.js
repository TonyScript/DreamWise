#!/usr/bin/env node

/**
 * Script to create missing dream interpretation pages
 */

const fs = require('fs');
const path = require('path');

// List of missing dream pages that need to be created
const missingDreams = [
    { name: 'spider', icon: 'fa-spider', color: 'from-red-500 to-pink-500', description: 'creativity, patience, and feminine power' },
    { name: 'cat', icon: 'fa-cat', color: 'from-violet-500 to-purple-500', description: 'independence, intuition, and mystery' },
    { name: 'tree', icon: 'fa-tree', color: 'from-green-500 to-emerald-500', description: 'growth, stability, and connection to nature' },
    { name: 'blood', icon: 'fa-tint', color: 'from-red-600 to-red-800', description: 'life force, vitality, and emotional intensity' },
    { name: 'teeth', icon: 'fa-tooth', color: 'from-cyan-400 to-blue-500', description: 'communication, confidence, and personal power' },
    { name: 'wedding', icon: 'fa-ring', color: 'from-rose-400 to-pink-500', description: 'union, commitment, and new beginnings' },
    { name: 'ocean', icon: 'fa-water', color: 'from-teal-400 to-blue-600', description: 'emotions, subconscious, and vast possibilities' },
    { name: 'mountain', icon: 'fa-mountain', color: 'from-stone-400 to-gray-600', description: 'challenges, achievement, and spiritual ascent' },
    { name: 'angel', icon: 'fa-angel', color: 'from-sky-400 to-blue-500', description: 'divine guidance, protection, and spiritual messages' }
];

// Template for dream pages
function createDreamPageTemplate(dreamData) {
    const { name, icon, color, description } = dreamData;
    const capitalizedName = name.charAt(0).toUpperCase() + name.slice(1);
    
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${capitalizedName} Dream Meaning - Multi-Faith Dream Interpretation | Dream Dictionary</title>
    <meta name="description" content="Discover the spiritual meaning of ${name} dreams through multiple faith perspectives. Get comprehensive dream interpretation from Christianity, Islam, Buddhism, Hinduism, Judaism, and universal wisdom.">
    <meta name="keywords" content="${name} dream meaning, ${name} dream interpretation, ${name} symbolism, spiritual ${name} meaning, dream dictionary ${name}, biblical ${name} dreams, islamic ${name} dreams">
    
    <!-- Open Graph Meta Tags -->
    <meta property="og:title" content="${capitalizedName} Dream Meaning - Multi-Faith Interpretation">
    <meta property="og:description" content="Explore the deep spiritual meanings of ${name} dreams from various religious and cultural perspectives.">
    <meta property="og:type" content="article">
    <meta property="og:url" content="https://dreaminterpretation.com/dream/${name}.html">
    <meta property="og:image" content="/assets/images/symbols/${name}-dream.jpg">
    
    <!-- Canonical URL -->
    <link rel="canonical" href="https://dreaminterpretation.com/dream/${name}.html">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        'inter': ['Inter', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    
    <!-- Inter Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/main.min.css">
</head>
<body>
    <!-- Navigation Header -->
    <nav class="fixed top-0 left-0 right-0 z-50 glass-card mx-4 mt-4 rounded-2xl">
        <div class="container mx-auto px-6 py-4">
            <div class="flex items-center justify-between">
                <!-- Logo -->
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center">
                        <i class="fas fa-moon text-white text-lg"></i>
                    </div>
                    <a href="../index.html" class="text-xl font-bold gradient-text">DreamWise</a>
                </div>
                
                <!-- Desktop Navigation -->
                <div class="hidden md:flex items-center space-x-8">
                    <a href="../index.html" class="text-white hover:text-purple-300 transition-colors duration-300 font-medium">Home</a>
                    <a href="../browse.html" class="text-white hover:text-purple-300 transition-colors duration-300 font-medium">Browse A-Z</a>
                    <a href="../categories.html" class="text-white hover:text-purple-300 transition-colors duration-300 font-medium">Categories</a>
                    <a href="../insights.html" class="text-white hover:text-purple-300 transition-colors duration-300 font-medium">Daily Insights</a>
                </div>
                
                <!-- Mobile Menu Button -->
                <button class="md:hidden mobile-menu-toggle text-white hover:text-purple-300 transition-colors duration-300">
                    <i class="fas fa-bars text-xl"></i>
                </button>
            </div>
            
            <!-- Mobile Navigation Menu -->
            <div class="mobile-menu hidden md:hidden mt-4 pt-4 border-t border-white/20">
                <div class="flex flex-col space-y-3">
                    <a href="../index.html" class="text-white hover:text-purple-300 transition-colors duration-300 font-medium py-2">Home</a>
                    <a href="../browse.html" class="text-white hover:text-purple-300 transition-colors duration-300 font-medium py-2">Browse A-Z</a>
                    <a href="../categories.html" class="text-white hover:text-purple-300 transition-colors duration-300 font-medium py-2">Categories</a>
                    <a href="../insights.html" class="text-white hover:text-purple-300 transition-colors duration-300 font-medium py-2">Daily Insights</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="pt-24 pb-20">
        <div class="container mx-auto px-6">
            <!-- Breadcrumb Navigation -->
            <nav class="mb-8">
                <div class="flex items-center space-x-2 text-sm text-gray-400">
                    <a href="../index.html" class="hover:text-purple-300 transition-colors duration-300">Home</a>
                    <i class="fas fa-chevron-right text-xs"></i>
                    <a href="../browse.html" class="hover:text-purple-300 transition-colors duration-300">Dream Dictionary</a>
                    <i class="fas fa-chevron-right text-xs"></i>
                    <span class="text-white">${capitalizedName}</span>
                </div>
            </nav>

            <!-- Dream Symbol Header -->
            <div class="glass-card p-8 mb-8 text-center">
                <div class="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-r ${color} flex items-center justify-center">
                    <i class="fas ${icon} text-3xl text-white"></i>
                </div>
                <h1 class="text-4xl md:text-5xl font-bold mb-4">
                    ${capitalizedName} <span class="gradient-text">Dream Meaning</span>
                </h1>
                <p class="text-xl text-gray-300 max-w-3xl mx-auto">
                    Discover the profound spiritual meanings of ${name} dreams representing ${description}
                </p>
            </div>

            <!-- Faith Perspective Switcher -->
            <div class="glass-card p-6 mb-8">
                <h2 class="text-xl font-bold text-center mb-6 text-gray-300">
                    Choose Your Faith Perspective
                </h2>
                <div class="flex flex-wrap justify-center gap-2 md:gap-4" role="tablist" aria-label="Faith perspectives">
                    <button class="faith-tab active" data-faith="general" role="tab" aria-selected="true" aria-controls="general-content" tabindex="0">
                        <i class="fas fa-globe mr-2 text-lg"></i>
                        <span class="hidden sm:inline font-medium">General</span>
                    </button>
                    <button class="faith-tab" data-faith="christianity" role="tab" aria-selected="false" aria-controls="christianity-content" tabindex="-1">
                        <i class="fas fa-cross mr-2 text-lg"></i>
                        <span class="hidden sm:inline font-medium">Christianity</span>
                    </button>
                    <button class="faith-tab" data-faith="islam" role="tab" aria-selected="false" aria-controls="islam-content" tabindex="-1">
                        <i class="fas fa-moon mr-2 text-lg"></i>
                        <span class="hidden sm:inline font-medium">Islam</span>
                    </button>
                    <button class="faith-tab" data-faith="buddhism" role="tab" aria-selected="false" aria-controls="buddhism-content" tabindex="-1">
                        <i class="fas fa-dharmachakra mr-2 text-lg"></i>
                        <span class="hidden sm:inline font-medium">Buddhism</span>
                    </button>
                    <button class="faith-tab" data-faith="hinduism" role="tab" aria-selected="false" aria-controls="hinduism-content" tabindex="-1">
                        <i class="fas fa-om mr-2 text-lg"></i>
                        <span class="hidden sm:inline font-medium">Hinduism</span>
                    </button>
                    <button class="faith-tab" data-faith="judaism" role="tab" aria-selected="false" aria-controls="judaism-content" tabindex="-1">
                        <i class="fas fa-star-of-david mr-2 text-lg"></i>
                        <span class="hidden sm:inline font-medium">Judaism</span>
                    </button>
                </div>
            </div>

            <!-- Faith Content Sections -->
            <div class="faith-content-container">
                <!-- General Interpretation -->
                <div class="faith-content active" id="general-content">
                    <div class="glass-card p-8 mb-8">
                        <h2 class="text-2xl font-bold mb-6 flex items-center">
                            <i class="fas fa-globe text-purple-400 mr-3"></i>
                            Universal Symbolism
                        </h2>
                        
                        <div class="space-y-6">
                            <div class="interpretation-section core-meaning">
                                <div class="section-header">
                                    <h3 class="text-xl font-semibold text-purple-300">Core Meaning</h3>
                                </div>
                                <div class="section-content">
                                    <p class="text-gray-300 leading-relaxed">
                                        ${capitalizedName} dreams represent ${description}. These powerful symbols in your dreams invite you to explore deeper aspects of your spiritual journey and personal growth.
                                    </p>
                                    <div class="interpretation-subsection">
                                        <h4>Key Themes</h4>
                                        <p>Spiritual Growth • Personal Transformation • Inner Wisdom • Life Lessons • Divine Guidance</p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="interpretation-section spiritual-guidance">
                                <div class="section-header">
                                    <h3 class="text-xl font-semibold text-blue-300">Spiritual Guidance</h3>
                                </div>
                                <div class="section-content">
                                    <p class="text-gray-300 leading-relaxed">
                                        This dream symbol encourages you to reflect on your current life path and consider how you can align more closely with your spiritual purpose and highest good.
                                    </p>
                                    <div class="spiritual-quote">
                                        <p>"Every symbol in your dreams carries a message from your higher self."</p>
                                        <div class="quote-attribution">— Universal Wisdom</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Christianity Interpretation -->
                <div class="faith-content" id="christianity-content">
                    <div class="glass-card p-8 mb-8">
                        <h2 class="text-2xl font-bold mb-6 flex items-center">
                            <i class="fas fa-cross text-blue-400 mr-3"></i>
                            Christian Perspective
                        </h2>
                        <p class="text-gray-300 leading-relaxed">
                            From a Christian perspective, ${name} dreams may represent God's guidance in your life and His call to spiritual growth. Seek prayer and scripture study for deeper understanding.
                        </p>
                        <div class="spiritual-quote mt-4">
                            <p>"Trust in the Lord with all your heart and lean not on your own understanding."</p>
                            <div class="quote-attribution">— Proverbs 3:5</div>
                        </div>
                    </div>
                </div>

                <!-- Islam Interpretation -->
                <div class="faith-content" id="islam-content">
                    <div class="glass-card p-8 mb-8">
                        <h2 class="text-2xl font-bold mb-6 flex items-center">
                            <i class="fas fa-moon text-teal-400 mr-3"></i>
                            Islamic Perspective
                        </h2>
                        <p class="text-gray-300 leading-relaxed">
                            In Islamic tradition, dreams are significant spiritual experiences. ${capitalizedName} dreams may indicate Allah's guidance and the need for increased devotion and righteous action.
                        </p>
                        <div class="spiritual-quote mt-4">
                            <p>"And whoever relies upon Allah - then He is sufficient for him."</p>
                            <div class="quote-attribution">— Quran 65:3</div>
                        </div>
                    </div>
                </div>

                <!-- Buddhism Interpretation -->
                <div class="faith-content" id="buddhism-content">
                    <div class="glass-card p-8 mb-8">
                        <h2 class="text-2xl font-bold mb-6 flex items-center">
                            <i class="fas fa-dharmachakra text-orange-400 mr-3"></i>
                            Buddhist Perspective
                        </h2>
                        <p class="text-gray-300 leading-relaxed">
                            Buddhist interpretation sees ${name} dreams as reflections of your spiritual progress and the impermanent nature of existence. They encourage mindfulness and compassion.
                        </p>
                        <div class="spiritual-quote mt-4">
                            <p>"The mind is everything. What you think you become."</p>
                            <div class="quote-attribution">— Buddha</div>
                        </div>
                    </div>
                </div>

                <!-- Hinduism Interpretation -->
                <div class="faith-content" id="hinduism-content">
                    <div class="glass-card p-8 mb-8">
                        <h2 class="text-2xl font-bold mb-6 flex items-center">
                            <i class="fas fa-om text-saffron-400 mr-3"></i>
                            Hindu Perspective
                        </h2>
                        <p class="text-gray-300 leading-relaxed">
                            In Hindu tradition, ${name} dreams may represent your dharmic path and spiritual evolution. They encourage you to align with your life's purpose and divine will.
                        </p>
                        <div class="spiritual-quote mt-4">
                            <p>"You have the right to perform your actions, but you are not entitled to the fruits of action."</p>
                            <div class="quote-attribution">— Bhagavad Gita 2.47</div>
                        </div>
                    </div>
                </div>

                <!-- Judaism Interpretation -->
                <div class="faith-content" id="judaism-content">
                    <div class="glass-card p-8 mb-8">
                        <h2 class="text-2xl font-bold mb-6 flex items-center">
                            <i class="fas fa-star-of-david text-blue-400 mr-3"></i>
                            Jewish Perspective
                        </h2>
                        <p class="text-gray-300 leading-relaxed">
                            Jewish interpretation of ${name} dreams emphasizes divine providence and your role in tikkun olam (repairing the world). Consider how this dream guides your righteous actions.
                        </p>
                        <div class="spiritual-quote mt-4">
                            <p>"In all your ways acknowledge Him, and He will direct your paths."</p>
                            <div class="quote-attribution">— Proverbs 3:6</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Related Dreams Section -->
            <div class="glass-card p-8 mb-8">
                <h2 class="text-2xl font-bold mb-6 flex items-center">
                    <i class="fas fa-link text-purple-400 mr-3"></i>
                    Related Dream Symbols
                </h2>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <a href="water.html" class="glass-card hover-scale p-4 text-center group">
                        <div class="w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-r from-blue-500 to-cyan-500 flex items-center justify-center">
                            <i class="fas fa-water text-xl text-white"></i>
                        </div>
                        <h3 class="text-sm font-semibold text-white group-hover:text-purple-300">Water</h3>
                    </a>
                    <a href="fire.html" class="glass-card hover-scale p-4 text-center group">
                        <div class="w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-r from-orange-500 to-red-500 flex items-center justify-center">
                            <i class="fas fa-fire text-xl text-white"></i>
                        </div>
                        <h3 class="text-sm font-semibold text-white group-hover:text-purple-300">Fire</h3>
                    </a>
                    <a href="snake.html" class="glass-card hover-scale p-4 text-center group">
                        <div class="w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-r from-red-500 to-pink-500 flex items-center justify-center">
                            <i class="fas fa-snake text-xl text-white"></i>
                        </div>
                        <h3 class="text-sm font-semibold text-white group-hover:text-purple-300">Snake</h3>
                    </a>
                    <a href="flying.html" class="glass-card hover-scale p-4 text-center group">
                        <div class="w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-r from-purple-500 to-indigo-500 flex items-center justify-center">
                            <i class="fas fa-dove text-xl text-white"></i>
                        </div>
                        <h3 class="text-sm font-semibold text-white group-hover:text-purple-300">Flying</h3>
                    </a>
                </div>
            </div>
        </div>
    </main>

    <!-- JavaScript -->
    <script src="../assets/js/main.min.js"></script>
    <script src="../assets/js/faith-switcher.min.js"></script>
</body>
</html>`;
}

// Create all missing dream pages
console.log('🔧 Creating missing dream interpretation pages...\n');

let created = 0;
let errors = 0;

missingDreams.forEach(dreamData => {
    const filename = path.join('dream', `${dreamData.name}.html`);
    const content = createDreamPageTemplate(dreamData);
    
    try {
        fs.writeFileSync(filename, content, 'utf8');
        console.log(`✅ Created: ${filename}`);
        created++;
    } catch (error) {
        console.log(`❌ Error creating ${filename}: ${error.message}`);
        errors++;
    }
});

console.log(`\n📊 Summary:`);
console.log(`✅ Created: ${created} pages`);
console.log(`❌ Errors: ${errors} pages`);

if (errors === 0) {
    console.log('\n🎉 All missing dream pages created successfully!');
    console.log('Users will no longer encounter 404 errors when clicking dream symbol links.');
} else {
    console.log('\n⚠️  Some pages could not be created. Please check the errors above.');
}